﻿namespace Tlieta.Pdms.Views.Shared
{
    partial class Statistics
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Charting.GradientElement gradientElement109 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement110 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement111 = new Telerik.Charting.GradientElement();
            Telerik.Charting.Styles.ChartMargins chartMargins37 = new Telerik.Charting.Styles.ChartMargins();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Statistics));
            Telerik.Charting.Styles.ChartMargins chartMargins38 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartMargins chartMargins39 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartPaddings chartPaddings13 = new Telerik.Charting.Styles.ChartPaddings();
            Telerik.Charting.ChartSeries chartSeries25 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement112 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement113 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement114 = new Telerik.Charting.GradientElement();
            Telerik.Charting.ChartSeries chartSeries26 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement115 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement116 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement117 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement118 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement119 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement120 = new Telerik.Charting.GradientElement();
            Telerik.Charting.Styles.ChartMargins chartMargins40 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartMargins chartMargins41 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartMargins chartMargins42 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartPaddings chartPaddings14 = new Telerik.Charting.Styles.ChartPaddings();
            Telerik.Charting.ChartSeries chartSeries27 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement121 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement122 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement123 = new Telerik.Charting.GradientElement();
            Telerik.Charting.ChartSeries chartSeries28 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement124 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement125 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement126 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement127 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement128 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement129 = new Telerik.Charting.GradientElement();
            Telerik.Charting.Styles.ChartMargins chartMargins43 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartMargins chartMargins44 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartMargins chartMargins45 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartPaddings chartPaddings15 = new Telerik.Charting.Styles.ChartPaddings();
            Telerik.Charting.ChartSeries chartSeries29 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement130 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement131 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement132 = new Telerik.Charting.GradientElement();
            Telerik.Charting.ChartSeries chartSeries30 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement133 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement134 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement135 = new Telerik.Charting.GradientElement();
            this.pageviewStatistics = new Telerik.WinControls.UI.RadPageView();
            this.viewSurgeryCount = new Telerik.WinControls.UI.RadPageViewPage();
            this.btnChart1Bar = new Telerik.WinControls.UI.RadButton();
            this.btnChart1Pie = new Telerik.WinControls.UI.RadButton();
            this.btnRefreshChart1 = new Telerik.WinControls.UI.RadButton();
            this.chartSurgeryCount = new Telerik.WinControls.UI.RadChart();
            this.viewHospitalOperations = new Telerik.WinControls.UI.RadPageViewPage();
            this.btnChart2Bar = new Telerik.WinControls.UI.RadButton();
            this.btnCart2Pie = new Telerik.WinControls.UI.RadButton();
            this.btnRefreshChart2 = new Telerik.WinControls.UI.RadButton();
            this.chartOperationsCount = new Telerik.WinControls.UI.RadChart();
            this.viewMonthlyOperations = new Telerik.WinControls.UI.RadPageViewPage();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.ddlYear = new Telerik.WinControls.UI.RadDropDownList();
            this.btnChart3Line = new Telerik.WinControls.UI.RadButton();
            this.btnChart3Pie = new Telerik.WinControls.UI.RadButton();
            this.btnChart3Refresh = new Telerik.WinControls.UI.RadButton();
            this.chartMonthlyOperations = new Telerik.WinControls.UI.RadChart();
            this.telerikMetroTheme1 = new Telerik.WinControls.Themes.TelerikMetroTheme();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.ddlOpertaion = new Telerik.WinControls.UI.RadDropDownList();
            ((System.ComponentModel.ISupportInitialize)(this.pageviewStatistics)).BeginInit();
            this.pageviewStatistics.SuspendLayout();
            this.viewSurgeryCount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart1Bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart1Pie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRefreshChart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartSurgeryCount)).BeginInit();
            this.viewHospitalOperations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart2Bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCart2Pie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRefreshChart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartOperationsCount)).BeginInit();
            this.viewMonthlyOperations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart3Line)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart3Pie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart3Refresh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMonthlyOperations)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlOpertaion)).BeginInit();
            this.SuspendLayout();
            // 
            // pageviewStatistics
            // 
            this.pageviewStatistics.Controls.Add(this.viewSurgeryCount);
            this.pageviewStatistics.Controls.Add(this.viewHospitalOperations);
            this.pageviewStatistics.Controls.Add(this.viewMonthlyOperations);
            this.pageviewStatistics.Location = new System.Drawing.Point(3, 3);
            this.pageviewStatistics.Name = "pageviewStatistics";
            this.pageviewStatistics.SelectedPage = this.viewMonthlyOperations;
            this.pageviewStatistics.Size = new System.Drawing.Size(1294, 594);
            this.pageviewStatistics.TabIndex = 0;
            this.pageviewStatistics.ThemeName = "TelerikMetro";
            this.pageviewStatistics.ViewMode = Telerik.WinControls.UI.PageViewMode.Backstage;
            // 
            // viewSurgeryCount
            // 
            this.viewSurgeryCount.Controls.Add(this.btnChart1Bar);
            this.viewSurgeryCount.Controls.Add(this.btnChart1Pie);
            this.viewSurgeryCount.Controls.Add(this.btnRefreshChart1);
            this.viewSurgeryCount.Controls.Add(this.chartSurgeryCount);
            this.viewSurgeryCount.Location = new System.Drawing.Point(205, 4);
            this.viewSurgeryCount.Name = "viewSurgeryCount";
            this.viewSurgeryCount.Size = new System.Drawing.Size(1085, 586);
            this.viewSurgeryCount.Text = "Operations / Hospital";
            // 
            // btnChart1Bar
            // 
            this.btnChart1Bar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnChart1Bar.Location = new System.Drawing.Point(990, 76);
            this.btnChart1Bar.Name = "btnChart1Bar";
            this.btnChart1Bar.Size = new System.Drawing.Size(92, 32);
            this.btnChart1Bar.TabIndex = 4;
            this.btnChart1Bar.Text = "Bar";
            this.btnChart1Bar.ThemeName = "TelerikMetro";
            this.btnChart1Bar.Click += new System.EventHandler(this.btnChart1Bar_Click);
            // 
            // btnChart1Pie
            // 
            this.btnChart1Pie.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnChart1Pie.Location = new System.Drawing.Point(990, 38);
            this.btnChart1Pie.Name = "btnChart1Pie";
            this.btnChart1Pie.Size = new System.Drawing.Size(92, 32);
            this.btnChart1Pie.TabIndex = 3;
            this.btnChart1Pie.Text = "Pie";
            this.btnChart1Pie.ThemeName = "TelerikMetro";
            this.btnChart1Pie.Click += new System.EventHandler(this.btnChart1Pie_Click);
            // 
            // btnRefreshChart1
            // 
            this.btnRefreshChart1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnRefreshChart1.Location = new System.Drawing.Point(990, 0);
            this.btnRefreshChart1.Name = "btnRefreshChart1";
            this.btnRefreshChart1.Size = new System.Drawing.Size(92, 32);
            this.btnRefreshChart1.TabIndex = 2;
            this.btnRefreshChart1.Text = "Refresh";
            this.btnRefreshChart1.ThemeName = "TelerikMetro";
            this.btnRefreshChart1.Click += new System.EventHandler(this.btnRefreshChart1_Click);
            // 
            // chartSurgeryCount
            // 
            this.chartSurgeryCount.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.chartSurgeryCount.Appearance.Border.Width = 5F;
            gradientElement109.Color = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(120)))), ((int)(((byte)(179)))));
            gradientElement110.Color = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(189)))), ((int)(((byte)(254)))));
            gradientElement110.Position = 0.5F;
            gradientElement111.Color = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(120)))), ((int)(((byte)(179)))));
            gradientElement111.Position = 1F;
            this.chartSurgeryCount.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement109,
            gradientElement110,
            gradientElement111});
            this.chartSurgeryCount.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartMargins37.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins37.Bottom")));
            chartMargins37.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins37.Left")));
            chartMargins37.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins37.Right")));
            chartMargins37.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins37.Top")));
            this.chartSurgeryCount.ChartTitle.Appearance.Dimensions.Margins = chartMargins37;
            this.chartSurgeryCount.ChartTitle.Appearance.FillStyle.MainColor = System.Drawing.Color.Empty;
            this.chartSurgeryCount.ChartTitle.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartSurgeryCount.ChartTitle.TextBlock.Appearance.TextProperties.Font = new System.Drawing.Font("Verdana", 14F);
            this.chartSurgeryCount.ChartTitle.TextBlock.Text = "Number of surgeries performed in each hospital";
            this.chartSurgeryCount.Legend.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            chartMargins38.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins38.Bottom")));
            chartMargins38.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins38.Right")));
            this.chartSurgeryCount.Legend.Appearance.Dimensions.Margins = chartMargins38;
            this.chartSurgeryCount.Legend.Appearance.FillStyle.GammaCorrection = false;
            this.chartSurgeryCount.Legend.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartSurgeryCount.Legend.Appearance.ItemTextAppearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartSurgeryCount.Legend.TextBlock.Appearance.Position.AlignedPosition = Telerik.Charting.Styles.AlignedPositions.Top;
            this.chartSurgeryCount.Legend.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartSurgeryCount.Location = new System.Drawing.Point(0, 0);
            this.chartSurgeryCount.Name = "chartSurgeryCount";
            this.chartSurgeryCount.PlotArea.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(180)))), ((int)(((byte)(223)))));
            chartMargins39.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins39.Bottom")));
            chartMargins39.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins39.Left")));
            chartMargins39.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins39.Right")));
            chartMargins39.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins39.Top")));
            this.chartSurgeryCount.PlotArea.Appearance.Dimensions.Margins = chartMargins39;
            this.chartSurgeryCount.PlotArea.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartSurgeryCount.PlotArea.Appearance.FillStyle.SecondColor = System.Drawing.Color.Transparent;
            this.chartSurgeryCount.PlotArea.XAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartSurgeryCount.PlotArea.XAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartSurgeryCount.PlotArea.XAxis.Appearance.MajorGridLines.Width = 0F;
            this.chartSurgeryCount.PlotArea.XAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartSurgeryCount.PlotArea.XAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartPaddings13.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartPaddings13.Bottom")));
            this.chartSurgeryCount.PlotArea.XAxis.AxisLabel.Appearance.Dimensions.Paddings = chartPaddings13;
            this.chartSurgeryCount.PlotArea.XAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartSurgeryCount.PlotArea.XAxis.MinValue = 1D;
            this.chartSurgeryCount.PlotArea.YAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartSurgeryCount.PlotArea.YAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(209)))), ((int)(((byte)(248)))));
            this.chartSurgeryCount.PlotArea.YAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartSurgeryCount.PlotArea.YAxis.Appearance.MinorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(209)))), ((int)(((byte)(248)))));
            this.chartSurgeryCount.PlotArea.YAxis.Appearance.MinorGridLines.Width = 0F;
            this.chartSurgeryCount.PlotArea.YAxis.Appearance.MinorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartSurgeryCount.PlotArea.YAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartSurgeryCount.PlotArea.YAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartSurgeryCount.PlotArea.YAxis.MaxValue = 90D;
            this.chartSurgeryCount.PlotArea.YAxis.Step = 10D;
            gradientElement112.Color = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            gradientElement113.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(239)))), ((int)(((byte)(252)))));
            gradientElement113.Position = 0.5F;
            gradientElement114.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(217)))), ((int)(((byte)(238)))));
            gradientElement114.Position = 1F;
            chartSeries25.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement112,
            gradientElement113,
            gradientElement114});
            chartSeries25.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartSeries25.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartSeries25.Name = "Series 1";
            chartSeries26.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(160)))), ((int)(((byte)(0)))));
            gradientElement115.Color = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(222)))), ((int)(((byte)(78)))));
            gradientElement116.Color = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(207)))), ((int)(((byte)(27)))));
            gradientElement116.Position = 0.5F;
            gradientElement117.Color = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(181)))), ((int)(((byte)(3)))));
            gradientElement117.Position = 1F;
            chartSeries26.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement115,
            gradientElement116,
            gradientElement117});
            chartSeries26.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartSeries26.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartSeries26.Name = "Series 2";
            this.chartSurgeryCount.Series.AddRange(new Telerik.Charting.ChartSeries[] {
            chartSeries25,
            chartSeries26});
            this.chartSurgeryCount.Size = new System.Drawing.Size(984, 580);
            this.chartSurgeryCount.Skin = "DeepBlue";
            this.chartSurgeryCount.TabIndex = 0;
            // 
            // viewHospitalOperations
            // 
            this.viewHospitalOperations.Controls.Add(this.btnChart2Bar);
            this.viewHospitalOperations.Controls.Add(this.btnCart2Pie);
            this.viewHospitalOperations.Controls.Add(this.btnRefreshChart2);
            this.viewHospitalOperations.Controls.Add(this.chartOperationsCount);
            this.viewHospitalOperations.Location = new System.Drawing.Point(205, 4);
            this.viewHospitalOperations.Name = "viewHospitalOperations";
            this.viewHospitalOperations.Size = new System.Drawing.Size(1085, 586);
            this.viewHospitalOperations.Text = "Operation Types / Count";
            // 
            // btnChart2Bar
            // 
            this.btnChart2Bar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnChart2Bar.Location = new System.Drawing.Point(990, 76);
            this.btnChart2Bar.Name = "btnChart2Bar";
            this.btnChart2Bar.Size = new System.Drawing.Size(92, 32);
            this.btnChart2Bar.TabIndex = 7;
            this.btnChart2Bar.Text = "Bar";
            this.btnChart2Bar.ThemeName = "TelerikMetro";
            this.btnChart2Bar.Click += new System.EventHandler(this.btnChart2Bar_Click);
            // 
            // btnCart2Pie
            // 
            this.btnCart2Pie.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnCart2Pie.Location = new System.Drawing.Point(990, 38);
            this.btnCart2Pie.Name = "btnCart2Pie";
            this.btnCart2Pie.Size = new System.Drawing.Size(92, 32);
            this.btnCart2Pie.TabIndex = 6;
            this.btnCart2Pie.Text = "Pie";
            this.btnCart2Pie.ThemeName = "TelerikMetro";
            this.btnCart2Pie.Click += new System.EventHandler(this.btnCart2Pie_Click);
            // 
            // btnRefreshChart2
            // 
            this.btnRefreshChart2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnRefreshChart2.Location = new System.Drawing.Point(990, 0);
            this.btnRefreshChart2.Name = "btnRefreshChart2";
            this.btnRefreshChart2.Size = new System.Drawing.Size(92, 32);
            this.btnRefreshChart2.TabIndex = 5;
            this.btnRefreshChart2.Text = "Refresh";
            this.btnRefreshChart2.ThemeName = "TelerikMetro";
            this.btnRefreshChart2.Click += new System.EventHandler(this.btnRefreshChart2_Click);
            // 
            // chartOperationsCount
            // 
            this.chartOperationsCount.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.chartOperationsCount.Appearance.Border.Width = 5F;
            gradientElement118.Color = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(120)))), ((int)(((byte)(179)))));
            gradientElement119.Color = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(189)))), ((int)(((byte)(254)))));
            gradientElement119.Position = 0.5F;
            gradientElement120.Color = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(120)))), ((int)(((byte)(179)))));
            gradientElement120.Position = 1F;
            this.chartOperationsCount.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement118,
            gradientElement119,
            gradientElement120});
            this.chartOperationsCount.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartMargins40.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins40.Bottom")));
            chartMargins40.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins40.Left")));
            chartMargins40.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins40.Right")));
            chartMargins40.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins40.Top")));
            this.chartOperationsCount.ChartTitle.Appearance.Dimensions.Margins = chartMargins40;
            this.chartOperationsCount.ChartTitle.Appearance.FillStyle.MainColor = System.Drawing.Color.Empty;
            this.chartOperationsCount.ChartTitle.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartOperationsCount.ChartTitle.TextBlock.Appearance.TextProperties.Font = new System.Drawing.Font("Verdana", 14F);
            this.chartOperationsCount.ChartTitle.TextBlock.Text = "Count of operation types";
            this.chartOperationsCount.Legend.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            chartMargins41.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins41.Bottom")));
            chartMargins41.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins41.Right")));
            this.chartOperationsCount.Legend.Appearance.Dimensions.Margins = chartMargins41;
            this.chartOperationsCount.Legend.Appearance.FillStyle.GammaCorrection = false;
            this.chartOperationsCount.Legend.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartOperationsCount.Legend.Appearance.ItemTextAppearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartOperationsCount.Legend.TextBlock.Appearance.Position.AlignedPosition = Telerik.Charting.Styles.AlignedPositions.Top;
            this.chartOperationsCount.Legend.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartOperationsCount.Location = new System.Drawing.Point(0, 0);
            this.chartOperationsCount.Name = "chartOperationsCount";
            this.chartOperationsCount.PlotArea.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(180)))), ((int)(((byte)(223)))));
            chartMargins42.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins42.Bottom")));
            chartMargins42.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins42.Left")));
            chartMargins42.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins42.Right")));
            chartMargins42.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins42.Top")));
            this.chartOperationsCount.PlotArea.Appearance.Dimensions.Margins = chartMargins42;
            this.chartOperationsCount.PlotArea.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartOperationsCount.PlotArea.Appearance.FillStyle.SecondColor = System.Drawing.Color.Transparent;
            this.chartOperationsCount.PlotArea.XAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartOperationsCount.PlotArea.XAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartOperationsCount.PlotArea.XAxis.Appearance.MajorGridLines.Width = 0F;
            this.chartOperationsCount.PlotArea.XAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartOperationsCount.PlotArea.XAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartPaddings14.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartPaddings14.Bottom")));
            this.chartOperationsCount.PlotArea.XAxis.AxisLabel.Appearance.Dimensions.Paddings = chartPaddings14;
            this.chartOperationsCount.PlotArea.XAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartOperationsCount.PlotArea.XAxis.MinValue = 1D;
            this.chartOperationsCount.PlotArea.YAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartOperationsCount.PlotArea.YAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(209)))), ((int)(((byte)(248)))));
            this.chartOperationsCount.PlotArea.YAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartOperationsCount.PlotArea.YAxis.Appearance.MinorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(209)))), ((int)(((byte)(248)))));
            this.chartOperationsCount.PlotArea.YAxis.Appearance.MinorGridLines.Width = 0F;
            this.chartOperationsCount.PlotArea.YAxis.Appearance.MinorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartOperationsCount.PlotArea.YAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartOperationsCount.PlotArea.YAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartOperationsCount.PlotArea.YAxis.MaxValue = 100D;
            this.chartOperationsCount.PlotArea.YAxis.Step = 10D;
            gradientElement121.Color = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            gradientElement122.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(239)))), ((int)(((byte)(252)))));
            gradientElement122.Position = 0.5F;
            gradientElement123.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(217)))), ((int)(((byte)(238)))));
            gradientElement123.Position = 1F;
            chartSeries27.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement121,
            gradientElement122,
            gradientElement123});
            chartSeries27.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartSeries27.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartSeries27.Name = "Series 1";
            chartSeries28.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(160)))), ((int)(((byte)(0)))));
            gradientElement124.Color = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(222)))), ((int)(((byte)(78)))));
            gradientElement125.Color = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(207)))), ((int)(((byte)(27)))));
            gradientElement125.Position = 0.5F;
            gradientElement126.Color = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(181)))), ((int)(((byte)(3)))));
            gradientElement126.Position = 1F;
            chartSeries28.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement124,
            gradientElement125,
            gradientElement126});
            chartSeries28.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartSeries28.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartSeries28.Name = "Series 2";
            this.chartOperationsCount.Series.AddRange(new Telerik.Charting.ChartSeries[] {
            chartSeries27,
            chartSeries28});
            this.chartOperationsCount.Size = new System.Drawing.Size(984, 580);
            this.chartOperationsCount.Skin = "DeepBlue";
            this.chartOperationsCount.TabIndex = 1;
            // 
            // viewMonthlyOperations
            // 
            this.viewMonthlyOperations.Controls.Add(this.ddlOpertaion);
            this.viewMonthlyOperations.Controls.Add(this.radLabel2);
            this.viewMonthlyOperations.Controls.Add(this.radLabel1);
            this.viewMonthlyOperations.Controls.Add(this.ddlYear);
            this.viewMonthlyOperations.Controls.Add(this.btnChart3Line);
            this.viewMonthlyOperations.Controls.Add(this.btnChart3Pie);
            this.viewMonthlyOperations.Controls.Add(this.btnChart3Refresh);
            this.viewMonthlyOperations.Controls.Add(this.chartMonthlyOperations);
            this.viewMonthlyOperations.Location = new System.Drawing.Point(205, 4);
            this.viewMonthlyOperations.Name = "viewMonthlyOperations";
            this.viewMonthlyOperations.Size = new System.Drawing.Size(1085, 586);
            this.viewMonthlyOperations.Text = "Operations / Monthly";
            // 
            // radLabel1
            // 
            this.radLabel1.Location = new System.Drawing.Point(295, 17);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(36, 19);
            this.radLabel1.TabIndex = 13;
            this.radLabel1.Text = "Year :";
            // 
            // ddlYear
            // 
            this.ddlYear.DropDownAnimationEnabled = true;
            this.ddlYear.Location = new System.Drawing.Point(337, 12);
            this.ddlYear.Name = "ddlYear";
            this.ddlYear.ShowImageInEditorArea = true;
            this.ddlYear.Size = new System.Drawing.Size(91, 23);
            this.ddlYear.TabIndex = 12;
            this.ddlYear.ThemeName = "TelerikMetro";
            this.ddlYear.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.ddlYear_SelectedIndexChanged);
            // 
            // btnChart3Line
            // 
            this.btnChart3Line.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnChart3Line.Location = new System.Drawing.Point(993, 138);
            this.btnChart3Line.Name = "btnChart3Line";
            this.btnChart3Line.Size = new System.Drawing.Size(92, 32);
            this.btnChart3Line.TabIndex = 11;
            this.btnChart3Line.Text = "Line";
            this.btnChart3Line.ThemeName = "TelerikMetro";
            this.btnChart3Line.Click += new System.EventHandler(this.btnChart3Line_Click);
            // 
            // btnChart3Pie
            // 
            this.btnChart3Pie.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnChart3Pie.Location = new System.Drawing.Point(993, 89);
            this.btnChart3Pie.Name = "btnChart3Pie";
            this.btnChart3Pie.Size = new System.Drawing.Size(92, 32);
            this.btnChart3Pie.TabIndex = 10;
            this.btnChart3Pie.Text = "Pie";
            this.btnChart3Pie.ThemeName = "TelerikMetro";
            this.btnChart3Pie.Click += new System.EventHandler(this.btnChart3Pie_Click);
            // 
            // btnChart3Refresh
            // 
            this.btnChart3Refresh.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnChart3Refresh.Location = new System.Drawing.Point(993, 41);
            this.btnChart3Refresh.Name = "btnChart3Refresh";
            this.btnChart3Refresh.Size = new System.Drawing.Size(92, 32);
            this.btnChart3Refresh.TabIndex = 9;
            this.btnChart3Refresh.Text = "Refresh";
            this.btnChart3Refresh.ThemeName = "TelerikMetro";
            this.btnChart3Refresh.Click += new System.EventHandler(this.btnChart3Refresh_Click);
            // 
            // chartMonthlyOperations
            // 
            this.chartMonthlyOperations.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.chartMonthlyOperations.Appearance.Border.Width = 5F;
            gradientElement127.Color = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(120)))), ((int)(((byte)(179)))));
            gradientElement128.Color = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(189)))), ((int)(((byte)(254)))));
            gradientElement128.Position = 0.5F;
            gradientElement129.Color = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(120)))), ((int)(((byte)(179)))));
            gradientElement129.Position = 1F;
            this.chartMonthlyOperations.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement127,
            gradientElement128,
            gradientElement129});
            this.chartMonthlyOperations.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartMargins43.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins43.Bottom")));
            chartMargins43.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins43.Left")));
            chartMargins43.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins43.Right")));
            chartMargins43.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins43.Top")));
            this.chartMonthlyOperations.ChartTitle.Appearance.Dimensions.Margins = chartMargins43;
            this.chartMonthlyOperations.ChartTitle.Appearance.FillStyle.MainColor = System.Drawing.Color.Empty;
            this.chartMonthlyOperations.ChartTitle.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartMonthlyOperations.ChartTitle.TextBlock.Appearance.TextProperties.Font = new System.Drawing.Font("Verdana", 14F);
            this.chartMonthlyOperations.ChartTitle.TextBlock.Text = "Operations Count Monthly";
            this.chartMonthlyOperations.DefaultType = Telerik.Charting.ChartSeriesType.Line;
            this.chartMonthlyOperations.Legend.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            chartMargins44.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins44.Bottom")));
            chartMargins44.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins44.Right")));
            this.chartMonthlyOperations.Legend.Appearance.Dimensions.Margins = chartMargins44;
            this.chartMonthlyOperations.Legend.Appearance.FillStyle.GammaCorrection = false;
            this.chartMonthlyOperations.Legend.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartMonthlyOperations.Legend.Appearance.ItemTextAppearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartMonthlyOperations.Legend.TextBlock.Appearance.Position.AlignedPosition = Telerik.Charting.Styles.AlignedPositions.Top;
            this.chartMonthlyOperations.Legend.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartMonthlyOperations.Location = new System.Drawing.Point(0, 41);
            this.chartMonthlyOperations.Name = "chartMonthlyOperations";
            this.chartMonthlyOperations.PlotArea.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(180)))), ((int)(((byte)(223)))));
            chartMargins45.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins45.Bottom")));
            chartMargins45.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins45.Left")));
            chartMargins45.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins45.Right")));
            chartMargins45.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins45.Top")));
            this.chartMonthlyOperations.PlotArea.Appearance.Dimensions.Margins = chartMargins45;
            this.chartMonthlyOperations.PlotArea.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartMonthlyOperations.PlotArea.Appearance.FillStyle.SecondColor = System.Drawing.Color.Transparent;
            this.chartMonthlyOperations.PlotArea.XAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartMonthlyOperations.PlotArea.XAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartMonthlyOperations.PlotArea.XAxis.Appearance.MajorGridLines.Width = 0F;
            this.chartMonthlyOperations.PlotArea.XAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartMonthlyOperations.PlotArea.XAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartPaddings15.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartPaddings15.Bottom")));
            this.chartMonthlyOperations.PlotArea.XAxis.AxisLabel.Appearance.Dimensions.Paddings = chartPaddings15;
            this.chartMonthlyOperations.PlotArea.XAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartMonthlyOperations.PlotArea.XAxis.MinValue = 1D;
            this.chartMonthlyOperations.PlotArea.YAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartMonthlyOperations.PlotArea.YAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(209)))), ((int)(((byte)(248)))));
            this.chartMonthlyOperations.PlotArea.YAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartMonthlyOperations.PlotArea.YAxis.Appearance.MinorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(209)))), ((int)(((byte)(248)))));
            this.chartMonthlyOperations.PlotArea.YAxis.Appearance.MinorGridLines.Width = 0F;
            this.chartMonthlyOperations.PlotArea.YAxis.Appearance.MinorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(183)))), ((int)(((byte)(226)))));
            this.chartMonthlyOperations.PlotArea.YAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            this.chartMonthlyOperations.PlotArea.YAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.LightSkyBlue;
            this.chartMonthlyOperations.PlotArea.YAxis.MaxValue = 90D;
            this.chartMonthlyOperations.PlotArea.YAxis.Step = 10D;
            gradientElement130.Color = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            gradientElement131.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(239)))), ((int)(((byte)(252)))));
            gradientElement131.Position = 0.5F;
            gradientElement132.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(217)))), ((int)(((byte)(238)))));
            gradientElement132.Position = 1F;
            chartSeries29.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement130,
            gradientElement131,
            gradientElement132});
            chartSeries29.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartSeries29.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            chartSeries29.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartSeries29.Name = "Series 1";
            chartSeries29.Type = Telerik.Charting.ChartSeriesType.Line;
            chartSeries30.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(160)))), ((int)(((byte)(0)))));
            gradientElement133.Color = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(222)))), ((int)(((byte)(78)))));
            gradientElement134.Color = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(207)))), ((int)(((byte)(27)))));
            gradientElement134.Position = 0.5F;
            gradientElement135.Color = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(181)))), ((int)(((byte)(3)))));
            gradientElement135.Position = 1F;
            chartSeries30.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement133,
            gradientElement134,
            gradientElement135});
            chartSeries30.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartSeries30.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(254)))), ((int)(((byte)(122)))));
            chartSeries30.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.White;
            chartSeries30.Name = "Series 2";
            chartSeries30.Type = Telerik.Charting.ChartSeriesType.Line;
            this.chartMonthlyOperations.Series.AddRange(new Telerik.Charting.ChartSeries[] {
            chartSeries29,
            chartSeries30});
            this.chartMonthlyOperations.Size = new System.Drawing.Size(987, 539);
            this.chartMonthlyOperations.Skin = "DeepBlue";
            this.chartMonthlyOperations.TabIndex = 8;
            // 
            // radLabel2
            // 
            this.radLabel2.Location = new System.Drawing.Point(3, 16);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(71, 19);
            this.radLabel2.TabIndex = 14;
            this.radLabel2.Text = "Operation : ";
            // 
            // ddlOpertaion
            // 
            this.ddlOpertaion.DropDownAnimationEnabled = true;
            this.ddlOpertaion.Location = new System.Drawing.Point(80, 12);
            this.ddlOpertaion.Name = "ddlOpertaion";
            this.ddlOpertaion.ShowImageInEditorArea = true;
            this.ddlOpertaion.Size = new System.Drawing.Size(200, 23);
            this.ddlOpertaion.TabIndex = 27;
            this.ddlOpertaion.ThemeName = "TelerikMetro";
            this.ddlOpertaion.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.ddlOpertaion_SelectedIndexChanged);
            // 
            // Statistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.pageviewStatistics);
            this.Name = "Statistics";
            this.Size = new System.Drawing.Size(1300, 600);
            this.Load += new System.EventHandler(this.Statistics_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pageviewStatistics)).EndInit();
            this.pageviewStatistics.ResumeLayout(false);
            this.viewSurgeryCount.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnChart1Bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart1Pie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRefreshChart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartSurgeryCount)).EndInit();
            this.viewHospitalOperations.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnChart2Bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCart2Pie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRefreshChart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartOperationsCount)).EndInit();
            this.viewMonthlyOperations.ResumeLayout(false);
            this.viewMonthlyOperations.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart3Line)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart3Pie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnChart3Refresh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMonthlyOperations)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlOpertaion)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadPageView pageviewStatistics;
        private Telerik.WinControls.UI.RadPageViewPage viewSurgeryCount;
        private Telerik.WinControls.UI.RadChart chartSurgeryCount;
        private Telerik.WinControls.UI.RadPageViewPage viewHospitalOperations;
        private Telerik.WinControls.UI.RadPageViewPage viewMonthlyOperations;
        private Telerik.WinControls.UI.RadButton btnRefreshChart1;
        private Telerik.WinControls.UI.RadButton btnChart1Pie;
        private Telerik.WinControls.UI.RadButton btnChart1Bar;
        private Telerik.WinControls.UI.RadChart chartOperationsCount;
        private Telerik.WinControls.UI.RadButton btnChart2Bar;
        private Telerik.WinControls.UI.RadButton btnCart2Pie;
        private Telerik.WinControls.UI.RadButton btnRefreshChart2;
        private Telerik.WinControls.UI.RadButton btnChart3Line;
        private Telerik.WinControls.UI.RadButton btnChart3Pie;
        private Telerik.WinControls.UI.RadButton btnChart3Refresh;
        private Telerik.WinControls.UI.RadChart chartMonthlyOperations;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadDropDownList ddlYear;
        private Telerik.WinControls.Themes.TelerikMetroTheme telerikMetroTheme1;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadDropDownList ddlOpertaion;
    }
}
