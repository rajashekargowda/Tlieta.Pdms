﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tlieta.Pdms.DataAccess
{
    public class BaseData
    {
        public PDMSModelContainer entities = new PDMSModelContainer();
    }
}
