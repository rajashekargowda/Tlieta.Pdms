﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tlieta.Pdms.DataAccess
{
    public static class Enums
    {
    }

    public enum Roles
    {
        Admin = 1,
        Surgeon = 2,
        Anaesthetist = 3,
        ScrubNurse = 4,
        FrontDesk = 5
    }
}
